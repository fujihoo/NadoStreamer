
#include "PRIME.h"

FILE* fp;
FILE* fp2;
